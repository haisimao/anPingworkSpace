"""__author__=李佳林"""
from scrapy import cmdline

cmdline.execute(['scrapy', 'crawl', 'secondHandHouse'])
